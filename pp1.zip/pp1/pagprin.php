<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Moda</title>
    <link rel="stylesheet" href="./css/bootstrap.min.css">
    <style>
        body {
            background: linear-gradient(135deg, #1f1f2e, #2d2d4b);
            color: white;
        }

        header {
            background-color: #29293d;
            padding: 20px;
            border-radius: 10px;
        }

        section {
            background-color: #2e2e4d;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 30px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);
        }

        h2 {
            text-transform: uppercase;
            font-weight: bold;
        }

        ol {
            padding-left: 20px;
        }

        ol li {
            margin-bottom: 5px;
        }

        img {
            border-radius: 10px;
            width: 100%;
            max-width: 500px;
        }

        footer {
            background-color: #29293d;
            color: #b3b3ff;
            padding: 10px;
            border-radius: 10px;
        }

        .btn {
            font-weight: bold;
            text-transform: uppercase;
        }
    </style>
</head>

<body>
    <div class="container my-5">
   
        <header class="mb-4 text-center">
            <h1 class="display-4 text-primary">Moda</h1>
        </header>

       
        <main>
           
            <section id="moda 1">
                <h2 class="text-center text-success"></h2>
                <p>
                La moda puede referirse a un conjunto de prendas, adornos y complementos, o al valor más frecuente de un conjunto de datos. 
Moda como conjunto de prendas
La moda es un reflejo de la sociedad y de la época en la que se vive. 
Se basa en gustos, costumbres y usos que son aceptados por la mayoría durante un periodo de tiempo. 
Las prendas de vestir revelan parte de la identidad de las personas. 
La moda puede incluir el conjunto de la vestimenta y los adornos de moda. 
Moda como valor más frecuente
En estadística, la moda es el número que se repite más veces en un conjunto de datos. 
A diferencia de la media y la mediana, la moda no requiere valores numéricos. 
Un conjunto de datos puede tener un modo, conocido como unimodal, o varios modos, denominados bimodal o multimodal. 
En trading técnico, la moda es el precio más frecuente para un período determinado. 
                </p>
                <div class="text-center mt-3">
                    <img src="img/1jpg" alt="Imagen " class="img-fluid">
                </div>
                <div class="text-center mt-3">
                    <a class="btn btn-primary w-75" href="./include/login.php">Escuchar</a>
                </div>
            </section>

            
            <section id="moda 2">
                <h2 class="text-center text-danger">moda</h2>
                <p>
                Qué es la moda?

La moda se refiere a las tendencias en diseño, vestimenta, accesorios y estilos que son populares en un momento y lugar específicos, marcando un cambio constante en la forma en que nos expresamos a través de la ropa y la imagen

                </p>
               
                <div class="text-center my-3">
                    <img src="img/download-2.jpg" alt="moda 3" class="img-fluid">
                </div>
                <div class="text-center">
                    <a class="btn btn-danger w-75" href="./include/login.html">Escuchar</a>
                </div>
            </section>

           
            <section id="jfsddfn">
                <h2 class="text-center text-info">aspectos a la moda </h2>
                <p>
               
Vestimenta: Incluye la ropa, calzado, accesorios y cosméticos. 
Estilos y tendencias: La moda se manifiesta en diferentes estilos y tendencias que cambian con el tiempo. 
Expresión personal: La moda permite a las personas expresar su identidad y pertenencia a un grupo social. 
Influencia cultural y social: La moda está influenciada por factores culturales, sociales y económicos. 

                </p>
               
                <div class="text-center my-3">
                    <img src="5.jpg" alt="sdgvjxv">
                </div>
                <div class="text-center">
                    <a class="btn btn-info w-75" href="./include/login.html">Escuchar</a>
                </div>
            </section>

          
            <section id="jfjsfjs">
                <h2 class="text-center text-dark"> ESTILOS DE MODA </h2>
                <p>
                Existen muchos tipos de moda, entre ellos el casual, el vintage, el urbano, el minimalista, el bohemio, el preppy, el deportivo, el chic y el artístico. 
Estilos de moda populares
Casual: Se caracteriza por la comodidad y la simplicidad en las prendas. 
Vintage: Se caracteriza por la influencia de modas pasadas y la implementación de prendas de segunda mano. 
Urbano: Se caracteriza por su comodidad, funcionalidad y estética audaz. 
Minimalista: Se caracteriza por su elegancia atemporal. 
Bohemio: Se caracteriza por la libertad y los colores vibrantes. 
Preppy: Es un estilo de moda que se caracteriza por ser elegante y sofisticado. 
Deportivo: Se caracteriza por la comodidad y la funcionalidad. 
Sporty chic: Es una variante más sofisticada del estilo deportivo. 

                </p>
                
                <div class="text-center my-3">
                    <img src="imagenes-1.jpg" alt="MODA 5" class="img-fluid">
                </div>
                <div class="text-center">
                    <a class="btn btn-dark w-75" href="./include/login.html">Escuchar</a>
                </div>
            </section>

          
            <section id="integrantes" class="text-center py-3">
                <h2>Integrantes</h2>
                <p><i>ZABDI BERENICE BARRAGAN GARCIA</i></p>
                <p><i>JESSICA SOFIA BARTOLO ATANACIO</i></p>
                <P><i>BRENDA ANAHI BALANZAR LOPEZ </i></P>
            </section>
        </main>

      
      
    </div>

   
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>